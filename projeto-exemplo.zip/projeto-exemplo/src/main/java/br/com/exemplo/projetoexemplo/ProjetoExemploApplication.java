package br.com.exemplo.projetoexemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoExemploApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoExemploApplication.class, args);
	}

}
