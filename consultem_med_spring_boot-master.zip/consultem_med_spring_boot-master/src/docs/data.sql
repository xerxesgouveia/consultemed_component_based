
INSERT INTO usuarios(nome,senha,ativo) VALUES ('carlos','$2a$10$0anDau3KstI0VK2A/0TPS.oty0GGEJxZ1AaLVyU05rxx8x2rlA.kK', true);
INSERT INTO usuarios(nome,senha,ativo) VALUES ('maria','$2a$10$0anDau3KstI0VK2A/0TPS.oty0GGEJxZ1AaLVyU05rxx8x2rlA.kK', true);
 
INSERT INTO usuarios_roles (nome, role) VALUES ('carlos', 'ROLE_USER');
INSERT INTO usuarios_roles (nome, role) VALUES ('carlos', 'ROLE_ADMIN');
INSERT INTO usuarios_roles (nome, role) VALUES ('maria', 'ROLE_USER');


