package br.com.medico.dto;

import lombok.Data;

@Data
public class MedicoFiltroDTO {
	
	private String nome;
}
