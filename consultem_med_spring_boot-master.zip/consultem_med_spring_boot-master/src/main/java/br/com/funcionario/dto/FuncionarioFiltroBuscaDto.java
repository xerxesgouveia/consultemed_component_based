package br.com.funcionario.dto;

import lombok.Data;

@Data
public class FuncionarioFiltroBuscaDto {
	
	private String nome;
}
