package br.com.paciente.dto;

import lombok.Data;

/**
 * @author ricardo belo
 *
 */

@Data
public class PacienteFiltroBuscaDto {
	
	private String nome;
}
